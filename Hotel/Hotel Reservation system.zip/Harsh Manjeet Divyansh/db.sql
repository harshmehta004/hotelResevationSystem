-- MySQL dump 10.13  Distrib 5.5.0-m2, for Win64 (unknown)
--
-- Host: localhost    Database: harsh
-- ------------------------------------------------------
-- Server version	5.5.0-m2-community

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `acc`
--

DROP TABLE IF EXISTS `acc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `acc` (
  `id` int(11) DEFAULT '3'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acc`
--

LOCK TABLES `acc` WRITE;
/*!40000 ALTER TABLE `acc` DISABLE KEYS */;
/*!40000 ALTER TABLE `acc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accomodation`
--

DROP TABLE IF EXISTS `accomodation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accomodation` (
  `email` varchar(255) DEFAULT NULL,
  `num_of_adults` varchar(255) DEFAULT NULL,
  `num_of_children` varchar(255) DEFAULT NULL,
  `num_of_nights` varchar(255) DEFAULT NULL,
  `type_of_room` varchar(255) DEFAULT NULL,
  `arrivalDate` varchar(255) DEFAULT NULL,
  `departureDate` varchar(255) DEFAULT NULL,
  `num_of_rooms` varchar(255) DEFAULT NULL,
  KEY `email` (`email`),
  CONSTRAINT `accomodation_ibfk_1` FOREIGN KEY (`email`) REFERENCES `hotel_registration` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accomodation`
--

LOCK TABLES `accomodation` WRITE;
/*!40000 ALTER TABLE `accomodation` DISABLE KEYS */;
INSERT INTO `accomodation` VALUES ('ex: myname@example.com','5','5','2','$100/Night Mountain View','20/07/2018','22/07/2018','3');
/*!40000 ALTER TABLE `accomodation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hotel_registration`
--

DROP TABLE IF EXISTS `hotel_registration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hotel_registration` (
  `fName` varchar(255) DEFAULT NULL,
  `lName` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `adress` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `area_Code` varchar(255) DEFAULT NULL,
  `phoneNo` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `arrivalDate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hotel_registration`
--

LOCK TABLES `hotel_registration` WRITE;
/*!40000 ALTER TABLE `hotel_registration` DISABLE KEYS */;
INSERT INTO `hotel_registration` VALUES ('fytgyu','hggfvgjh','F','Street AdressStreet Adress Line 2','City','State','787665','Nepal','Area Code','Phone Number','ex: myname@example.com','20/07/2018');
/*!40000 ALTER TABLE `hotel_registration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receptionist`
--

DROP TABLE IF EXISTS `receptionist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receptionist` (
  `uname` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receptionist`
--

LOCK TABLES `receptionist` WRITE;
/*!40000 ALTER TABLE `receptionist` DISABLE KEYS */;
INSERT INTO `receptionist` VALUES ('12345','3306');
/*!40000 ALTER TABLE `receptionist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roomno`
--

DROP TABLE IF EXISTS `roomno`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roomno` (
  `RoomNo` int(11) NOT NULL,
  `occupancy` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`RoomNo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roomno`
--

LOCK TABLES `roomno` WRITE;
/*!40000 ALTER TABLE `roomno` DISABLE KEYS */;
INSERT INTO `roomno` VALUES (1001,'Vacant'),(1002,'Occupied'),(1003,'Occupied'),(1004,'Vacant'),(1005,'Vacant'),(1006,'Vacant'),(1007,'Vacant'),(1008,'Vacant'),(1009,'Vacant'),(1010,'Vacant'),(1011,'Vacant'),(1012,'Vacant'),(1013,'Vacant'),(1014,'Vacant'),(1015,'Vacant'),(1016,'Vacant'),(1017,'Vacant'),(1018,'Vacant'),(1019,'Vacant'),(1020,'Vacant'),(1021,'Vacant'),(1022,'Vacant'),(1023,'Vacant'),(1024,'Vacant'),(1025,'Vacant'),(1026,'Vacant'),(1027,'Vacant'),(1028,'Vacant'),(1029,'Vacant'),(1030,'Vacant'),(1031,'Vacant'),(1032,'Vacant'),(1033,'Vacant'),(1034,'Vacant'),(1035,'Vacant'),(1036,'Vacant'),(1037,'Vacant'),(1038,'Vacant'),(1039,'Vacant'),(1040,'Vacant'),(1041,'Vacant'),(1042,'Vacant'),(1043,'Vacant'),(1044,'Vacant'),(1045,'Vacant'),(1046,'Vacant'),(1047,'Vacant'),(1048,'Vacant'),(1049,'Vacant'),(1050,'Vacant'),(1051,'Vacant'),(1052,'Vacant'),(1053,'Vacant'),(1054,'Vacant'),(1055,'Vacant'),(1056,'Vacant'),(1057,'Vacant'),(1058,'Vacant'),(1059,'Vacant'),(1060,'Vacant'),(1061,'Vacant'),(1062,'Vacant'),(1063,'Vacant'),(1064,'Vacant'),(1065,'Vacant'),(1066,'Vacant'),(1067,'Vacant'),(1068,'Vacant'),(1069,'Vacant'),(1070,'Vacant'),(1071,'Vacant'),(1072,'Vacant'),(1073,'Vacant'),(1074,'Vacant'),(1075,'Vacant'),(1076,'Vacant'),(1077,'Vacant'),(1078,'Vacant'),(1079,'Vacant'),(1080,'Vacant'),(1081,'Vacant'),(1082,'Vacant'),(1083,'Vacant'),(1084,'Vacant'),(1085,'Vacant'),(1086,'Vacant'),(1087,'Vacant'),(1088,'Vacant'),(1089,'Vacant'),(1090,'Vacant'),(1091,'Vacant'),(1092,'Vacant'),(1093,'Vacant'),(1094,'Vacant'),(1095,'Vacant'),(1096,'Vacant'),(1097,'Vacant'),(1098,'Vacant'),(1099,'Vacant'),(1100,'Vacant'),(1101,'Vacant'),(1102,'Vacant'),(1103,'Vacant'),(1104,'Vacant'),(1105,'Vacant'),(1106,'Vacant'),(1107,'Vacant'),(1108,'Vacant'),(1109,'Vacant'),(1110,'Vacant'),(1111,'Vacant'),(1112,'Vacant'),(1113,'Vacant'),(1114,'Vacant'),(1115,'Vacant'),(1116,'Vacant'),(1117,'Vacant'),(1118,'Vacant'),(1119,'Vacant'),(1120,'Vacant'),(1121,'Vacant'),(1122,'Vacant'),(1123,'Vacant'),(1124,'Vacant'),(1125,'Vacant'),(1126,'Vacant'),(1127,'Vacant'),(1128,'Vacant'),(1129,'Vacant'),(1130,'Vacant'),(1131,'Vacant'),(1132,'Vacant'),(1133,'Vacant'),(1134,'Vacant'),(1135,'Vacant'),(1136,'Vacant'),(1137,'Vacant'),(1138,'Vacant'),(1139,'Vacant'),(1140,'Vacant'),(1141,'Vacant'),(1142,'Vacant'),(1143,'Vacant'),(1144,'Vacant'),(1145,'Vacant'),(1146,'Vacant'),(1147,'Vacant'),(1148,'Vacant'),(1149,'Vacant'),(1150,'Vacant');
/*!40000 ALTER TABLE `roomno` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roomnocv`
--

DROP TABLE IF EXISTS `roomnocv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roomnocv` (
  `RoomNo` int(11) NOT NULL,
  `occupancy` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`RoomNo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roomnocv`
--

LOCK TABLES `roomnocv` WRITE;
/*!40000 ALTER TABLE `roomnocv` DISABLE KEYS */;
INSERT INTO `roomnocv` VALUES (3001,'Vacant'),(3002,'Vacant'),(3003,'Vacant'),(3004,'Vacant'),(3005,'Vacant'),(3006,'Vacant'),(3007,'Vacant'),(3008,'Vacant'),(3009,'Vacant'),(3010,'Vacant'),(3011,'Vacant'),(3012,'Vacant'),(3013,'Vacant'),(3014,'Vacant'),(3015,'Vacant'),(3016,'Vacant'),(3017,'Vacant'),(3018,'Vacant'),(3019,'Vacant'),(3020,'Vacant'),(3021,'Vacant'),(3022,'Vacant'),(3023,'Vacant'),(3024,'Vacant'),(3025,'Vacant'),(3026,'Vacant'),(3027,'Vacant'),(3028,'Vacant'),(3029,'Vacant'),(3030,'Vacant'),(3031,'Vacant'),(3032,'Vacant'),(3033,'Vacant'),(3034,'Vacant'),(3035,'Vacant'),(3036,'Vacant'),(3037,'Vacant'),(3038,'Vacant'),(3039,'Vacant'),(3040,'Vacant'),(3041,'Vacant'),(3042,'Vacant'),(3043,'Vacant'),(3044,'Vacant'),(3045,'Vacant'),(3046,'Vacant'),(3047,'Vacant'),(3048,'Vacant'),(3049,'Vacant'),(3050,'Vacant'),(3051,'Vacant'),(3052,'Vacant'),(3053,'Vacant'),(3054,'Vacant'),(3055,'Vacant'),(3056,'Vacant'),(3057,'Vacant'),(3058,'Vacant'),(3059,'Vacant'),(3060,'Vacant'),(3061,'Vacant'),(3062,'Vacant'),(3063,'Vacant'),(3064,'Vacant'),(3065,'Vacant'),(3066,'Vacant'),(3067,'Vacant'),(3068,'Vacant'),(3069,'Vacant'),(3070,'Vacant'),(3071,'Vacant'),(3072,'Vacant'),(3073,'Vacant'),(3074,'Vacant'),(3075,'Vacant'),(3076,'Vacant'),(3077,'Vacant'),(3078,'Vacant'),(3079,'Vacant'),(3080,'Vacant'),(3081,'Vacant'),(3082,'Vacant'),(3083,'Vacant'),(3084,'Vacant'),(3085,'Vacant'),(3086,'Vacant'),(3087,'Vacant'),(3088,'Vacant'),(3089,'Vacant'),(3090,'Vacant'),(3091,'Vacant'),(3092,'Vacant'),(3093,'Vacant'),(3094,'Vacant'),(3095,'Vacant'),(3096,'Vacant'),(3097,'Vacant'),(3098,'Vacant'),(3099,'Vacant'),(3100,'Vacant'),(3101,'Vacant'),(3102,'Vacant'),(3103,'Vacant'),(3104,'Vacant'),(3105,'Vacant'),(3106,'Vacant'),(3107,'Vacant'),(3108,'Vacant'),(3109,'Vacant'),(3110,'Vacant'),(3111,'Vacant'),(3112,'Vacant'),(3113,'Vacant'),(3114,'Vacant'),(3115,'Vacant'),(3116,'Vacant'),(3117,'Vacant'),(3118,'Vacant'),(3119,'Vacant'),(3120,'Vacant'),(3121,'Vacant'),(3122,'Vacant'),(3123,'Vacant'),(3124,'Vacant'),(3125,'Vacant'),(3126,'Vacant'),(3127,'Vacant'),(3128,'Vacant'),(3129,'Vacant'),(3130,'Vacant'),(3131,'Vacant'),(3132,'Vacant'),(3133,'Vacant'),(3134,'Vacant'),(3135,'Vacant'),(3136,'Vacant'),(3137,'Vacant'),(3138,'Vacant'),(3139,'Vacant'),(3140,'Vacant'),(3141,'Vacant'),(3142,'Vacant'),(3143,'Vacant'),(3144,'Vacant'),(3145,'Vacant'),(3146,'Vacant'),(3147,'Vacant'),(3148,'Vacant'),(3149,'Vacant'),(3150,'Vacant');
/*!40000 ALTER TABLE `roomnocv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roomnoov`
--

DROP TABLE IF EXISTS `roomnoov`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roomnoov` (
  `RoomNo` int(11) NOT NULL,
  `occupancy` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`RoomNo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roomnoov`
--

LOCK TABLES `roomnoov` WRITE;
/*!40000 ALTER TABLE `roomnoov` DISABLE KEYS */;
INSERT INTO `roomnoov` VALUES (2001,'Vacant'),(2002,'Vacant'),(2003,'Vacant'),(2004,'Vacant'),(2005,'Vacant'),(2006,'Vacant'),(2007,'Vacant'),(2008,'Vacant'),(2009,'Vacant'),(2010,'Vacant'),(2011,'Vacant'),(2012,'Vacant'),(2013,'Vacant'),(2014,'Vacant'),(2015,'Vacant'),(2016,'Vacant'),(2017,'Vacant'),(2018,'Vacant'),(2019,'Vacant'),(2020,'Vacant'),(2021,'Vacant'),(2022,'Vacant'),(2023,'Vacant'),(2024,'Vacant'),(2025,'Vacant'),(2026,'Vacant'),(2027,'Vacant'),(2028,'Vacant'),(2029,'Vacant'),(2030,'Vacant'),(2031,'Vacant'),(2032,'Vacant'),(2033,'Vacant'),(2034,'Vacant'),(2035,'Vacant'),(2036,'Vacant'),(2037,'Vacant'),(2038,'Vacant'),(2039,'Vacant'),(2040,'Vacant'),(2041,'Vacant'),(2042,'Vacant'),(2043,'Vacant'),(2044,'Vacant'),(2045,'Vacant'),(2046,'Vacant'),(2047,'Vacant'),(2048,'Vacant'),(2049,'Vacant'),(2050,'Vacant'),(2051,'Vacant'),(2052,'Vacant'),(2053,'Vacant'),(2054,'Vacant'),(2055,'Vacant'),(2056,'Vacant'),(2057,'Vacant'),(2058,'Vacant'),(2059,'Vacant'),(2060,'Vacant'),(2061,'Vacant'),(2062,'Vacant'),(2063,'Vacant'),(2064,'Vacant'),(2065,'Vacant'),(2066,'Vacant'),(2067,'Vacant'),(2068,'Vacant'),(2069,'Vacant'),(2070,'Vacant'),(2071,'Vacant'),(2072,'Vacant'),(2073,'Vacant'),(2074,'Vacant'),(2075,'Vacant'),(2076,'Vacant'),(2077,'Vacant'),(2078,'Vacant'),(2079,'Vacant'),(2080,'Vacant'),(2081,'Vacant'),(2082,'Vacant'),(2083,'Vacant'),(2084,'Vacant'),(2085,'Vacant'),(2086,'Vacant'),(2087,'Vacant'),(2088,'Vacant'),(2089,'Vacant'),(2090,'Vacant'),(2091,'Vacant'),(2092,'Vacant'),(2093,'Vacant'),(2094,'Vacant'),(2095,'Vacant'),(2096,'Vacant'),(2097,'Vacant'),(2098,'Vacant'),(2099,'Vacant'),(2100,'Vacant'),(2101,'Vacant'),(2102,'Vacant'),(2103,'Vacant'),(2104,'Vacant'),(2105,'Vacant'),(2106,'Vacant'),(2107,'Vacant'),(2108,'Vacant'),(2109,'Vacant'),(2110,'Vacant'),(2111,'Vacant'),(2112,'Vacant'),(2113,'Vacant'),(2114,'Vacant'),(2115,'Vacant'),(2116,'Vacant'),(2117,'Vacant'),(2118,'Vacant'),(2119,'Vacant'),(2120,'Vacant'),(2121,'Vacant'),(2122,'Vacant'),(2123,'Vacant'),(2124,'Vacant'),(2125,'Vacant'),(2126,'Vacant'),(2127,'Vacant'),(2128,'Vacant'),(2129,'Vacant'),(2130,'Vacant'),(2131,'Vacant'),(2132,'Vacant'),(2133,'Vacant'),(2134,'Vacant'),(2135,'Vacant'),(2136,'Vacant'),(2137,'Vacant'),(2138,'Vacant'),(2139,'Vacant'),(2140,'Vacant'),(2141,'Vacant'),(2142,'Vacant'),(2143,'Vacant'),(2144,'Vacant'),(2145,'Vacant'),(2146,'Vacant'),(2147,'Vacant'),(2148,'Vacant'),(2149,'Vacant'),(2150,'Vacant');
/*!40000 ALTER TABLE `roomnoov` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rooms`
--

DROP TABLE IF EXISTS `rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rooms` (
  `mountain_view` int(11) DEFAULT '150',
  `ocean_view` int(11) DEFAULT '150',
  `city_view` int(11) DEFAULT '150',
  `MVRoom` int(11) DEFAULT NULL,
  `OVRoom` int(11) DEFAULT NULL,
  `CVRoom` int(11) DEFAULT NULL,
  `mark` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rooms`
--

LOCK TABLES `rooms` WRITE;
/*!40000 ALTER TABLE `rooms` DISABLE KEYS */;
INSERT INTO `rooms` VALUES (148,150,150,2,0,0,0);
/*!40000 ALTER TABLE `rooms` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-20 12:59:46
