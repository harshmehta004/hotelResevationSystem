
package javaproject;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
//import static java.lang.Integer.parseInt;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import javax.swing.*;
import static javax.swing.JFrame.EXIT_ON_CLOSE;

public class Entrypage extends JFrame {
    int x,y,z1;
    
    JLabel l4,l,l1,l2,l3,l5,l6,l7;
    JLabel ll;ImageIcon ii;
    JTextField t1,t2,t3,t4,t5;
    JTextArea ta;
    JTextField t6,t7,t8,t9,t10;
    JComboBox c;
    JButton b;
    RoomType r2;
    JRadioButton r,r1;
    ButtonGroup b01;
  public Entrypage(){
        setVisible(true);
        setSize(1366, 768);
        setTitle("Registration Form");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(HIDE_ON_CLOSE);
        setLayout(null);
        
        //
        ll=new JLabel();
        ll.setBounds(0, 0, 1366, 768);
        ii=new ImageIcon("F:\\image.jpeg");
        //l.setIcon(i);
        ImageIcon img=new ImageIcon(ii.getImage().getScaledInstance(1366,768, Image.SCALE_SMOOTH));
        ll.setIcon(img);
        getContentPane().add(ll);
        //
        
        l=new JLabel("Lalit Hotel "); 
        l.setBounds(450,10,800,30);
        l.setFont(new Font("Serif",Font.ITALIC,40));
       l.setForeground(Color.MAGENTA);
        ll.add(l);
       
        //JLabel x=new JLabel("Registration Form");
        //x.setBounds(570, 50, 290, 90);
       // x.setFont(new Font("Serif",Font.BOLD,20));
     //  // x.setForeground(Color.BLACK);
       // ll.add(x);
        JLabel l1=new JLabel("First Name:");
        l1.setBounds(410, 120, 140, 40);
        l1.setFont(new Font("Serif",Font.BOLD,25));
        l1.setForeground(Color.YELLOW);
        ll.add(l1);
        t1=new JTextField(10);
        t1.setBounds(560, 120, 240,40);
        ll.add(t1);
        l2=new JLabel("LastName:");
        l2.setBounds(810, 120, 140, 40);
        l2.setFont(new Font("Serif",Font.BOLD,25));
        l2.setForeground(Color.YELLOW);
        ll.add(l2);
        t2=new JTextField(10);
        t2.setBounds(970, 120, 240, 40);
        ll.add(t2);
        JLabel l8 = new JLabel("Gender:");
        l8.setBounds(410, 180, 140, 40);
        l8.setFont(new Font("Serif",Font.BOLD,25));
        l8.setForeground(Color.ORANGE);
        ll.add(l8);
        r=new JRadioButton("Male");
        r.setBounds(560, 180,73,40);
        r.setBackground(Color.blue);
        r.setForeground(Color.black);
        r.setFont(new Font("Serif",Font.BOLD,19));
        //r.setBackground(Color.WHITE);
        ll.add(r);
        r1=new JRadioButton("Female");
        r1.setBackground(Color.blue);
        r1.setForeground(Color.black);
        r1.setBounds(680, 180, 90, 40);
        r1.setFont(new Font("Serif",Font.BOLD,19));
        //r1.setBackground(Color.WHITE);
        ll.add(r1);
        //
        b01=new ButtonGroup();
        b01.add(r);
        b01.add(r1);
        
        
        l3=new JLabel("Adress:");
        l3.setBounds(410, 240, 140,40);
        l3.setFont(new Font("Serif",Font.BOLD,25));
        l3.setForeground(Color.YELLOW);
        ll.add(l3);
        t6=new JTextField("Street Adress");
        t6.setBounds(560,240,240,40);
        ll.add(t6);
        t7=new JTextField("Street Adress Line 2");
        t7.setBounds(560,300,240,40);
        ll.add(t7);
        t8=new JTextField("City");
        t8.setBounds(810, 240, 240,40);
        ll.add(t8);
        t9=new JTextField("State");
        t9.setBounds(810, 300, 240,40);
        ll.add(t9);
        
        /*ta=new JTextArea( 4,30);
        ta.setBounds(100, 130, 200, 120);
        add(ta);*/
        l4=new JLabel("Pincode:");
        l4.setBounds(410, 360, 140,40);
        l4.setFont(new Font("Serif",Font.BOLD,25));
        l4.setForeground(Color.YELLOW);
        ll.add(l4);
        t3=new JTextField(6);
        t3.setBounds(560, 360, 240,40);
        ll.add(t3);
        l5=new JLabel("Country:");
        l5.setBounds(410, 420, 140,40);
        l5.setFont(new Font("Serif",Font.BOLD,25));
        l5.setForeground(Color.YELLOW);
        ll.add(l5);
        c=new JComboBox();
        c.setBounds(560, 420, 240,40);
        c.addItem("Select Country");
        c.addItem("India");
        c.addItem("Nepal");
        c.addItem("Bhutan");
        c.addItem("Iceland");
        ll.add(c);
        l6 = new JLabel("Phone No. :");
        l6.setBounds(410, 480,140,40);
        l6.setFont(new Font("Serif",Font.BOLD,25));
        l6.setForeground(Color.YELLOW);
        ll.add(l6);
        t10=new JTextField("Area Code");
        t10.setBounds(560,480,60,40);
        ll.add(t10);
        t4=new JTextField("Phone Number");
        t4.setBounds(630, 480, 180, 40);
        ll.add(t4);
        l7=new JLabel("E-Mail:");
        l7.setBounds(410, 540, 140,40);
        l7.setFont(new Font("Serif",Font.BOLD,25));
        l7.setForeground(Color.YELLOW);
        ll.add(l7);
        t5=new JTextField("ex: myname@example.com");
        t5.setBounds(560, 540, 240, 40);
        ll.add(t5);
       /* JLabel l8 = new JLabel("Gender:");
        l8.setBounds(10, 380, 90, 30);
        add(l8);
        JRadioButton r=new JRadioButton("Male");
        r.setBounds(100, 380, 100, 30);
        add(r);
        JRadioButton r1=new JRadioButton("Female");
        r1.setBounds(200, 380, 100, 30);
        add(r1);*/
        b=new JButton("NEXT >>");
        b.setBounds(700, 600, 120,50);
        b.setFont(new Font("Serif",Font.BOLD,20));
        ll.add(b);
        JButton b1=new JButton("Reset");
        b1.setBounds(840, 600, 120, 50);
        b1.setFont(new Font("Serif",Font.BOLD,20));
        ll.add(b1);
        b1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                java.awt.EventQueue.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        Entrypage e=new Entrypage();
                        setVisible(false);
                    }
                });  
            }
        });
        b.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                java.awt.EventQueue.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        
                        RoomType r2=new RoomType();
                    }
                });
                //RoomType r=new RoomType();
            }
        });
    }
   String s,s1,s2,s3,s4,s5,s6,s7,s8,s9,s10;
      char gender='0';
  public void data(){
     
      s=t1.getText();
      s1=t2.getText();
      s2=t3.getText(); 
      s3=t4.getText(); 
      s4=t5.getText(); 
      s5=t6.getText();
      s6=t7.getText(); 
      s7=t8.getText();
      s8=t9.getText();
      s9=t10.getText();
      if(r.isSelected())
          gender='M';
      else if(r1.isSelected())
          gender='F';
       s10 = (String)c.getSelectedItem();
      //System.out.println("s10"+s10);
  }
    class RoomType extends JFrame implements ActionListener{
JLabel l1,l2,l3,jl,l7;
JLabel jj;
ImageIcon ii1;

JRadioButton l4,l5,l6;
//JRadioButton rb1,rb2,rb3;
Font f = new Font ("Serif", Font.BOLD, 25);
JTextField t1,t2,t3,t,tf;
ButtonGroup bg;JButton jb;
    public RoomType(){
       
        setTitle("Accomodation");
        setVisible(true);
        setDefaultCloseOperation(HIDE_ON_CLOSE);
        setLocationRelativeTo(null);
        setSize(1366,768);
        setLayout(null);
        //setForeground(Color.YELLOW);
        jj=new JLabel();
        jj.setBounds(0, 0, 1366, 768);
        ii1=new ImageIcon("F:\\image.jpeg");
        //l.setIcon(i);
        ImageIcon img=new ImageIcon(ii1.getImage().getScaledInstance(1366,768, Image.SCALE_SMOOTH));
        jj.setIcon(img);
        getContentPane().add(jj);
        //jj.setForeground(Color.YELLOW);
        
        //
         l1=new JLabel("Number of Adults");
        l1.setFont(f);
        l1.setBounds(   300, 120, 200, 40);
        l1.setForeground(Color.YELLOW);
        jj.add(l1);
        t1=new JTextField("ex: 3");
        t1.setBounds(650,120,240,40);
        jj.add(t1);
        l2=new JLabel("Number of Children\n (if Any)");
        l2.setFont(f);
        l2.setForeground(Color.YELLOW);
        l2.setBounds(300, 170, 350, 40);
        jj.add(l2);
        t2=new JTextField("ex: 3");
        t2.setBounds(650, 170, 240, 40);
        jj.add(t2);
        l3=new JLabel("Number of Nights at Hotel");
        l3.setFont(f);l3.setForeground(Color.YELLOW);
        l3.setBounds(300, 220, 350, 40);
        jj.add(l3);
        t3=new JTextField("ex: 3");
        t3.setBounds(650, 220, 240, 40);
        jj.add(t3);
        jl=new JLabel("Choose the Type of room You Want");
        jl.setForeground(Color.YELLOW);
        jl.setFont(f);
        jl.setBounds(300, 270, 400, 40);
        jj.add(jl);
        l4=new JRadioButton("$100/Night Mountain View");
        l4.setBounds(350, 320, 250, 30);
        //l4.setForeground(Color.YELLOW);
        l4.setBackground(Color.cyan);
        jj.add(l4);
        l5=new JRadioButton("$120/Night Ocean View");
        //l5.setForeground(Color.YELLOW);
       l5.setBackground(Color.cyan);
        l5.setBounds(350, 370,250,30);
        jj.add(l5);
        l6=new JRadioButton("$140/Night City View");
        l6.setBounds(640, 320, 250, 30);
        //l6.setForeground(Color.YELLOW);
        l6.setBackground(Color.cyan);
        jj.add(l6);
        l7=new JLabel("____________________________________________________________________________________________________________________");
        l7.setBounds(100, 388,1400,30);
        l7.setFont(new Font("Serif",Font.BOLD,20));
        jj.add(l7);
        JLabel l8=new JLabel("Arrival-Date");
        l8.setFont(f);
        l8.setForeground(Color.YELLOW);
        l8.setBounds(300, 430, 250, 40);
        jj.add(l8);
        t=new JTextField("ex:dd/mm/yyyy");
        t.setBounds(600, 430, 250, 40);
        jj.add(t);
         JLabel l9=new JLabel("Departure-Date");
        l9.setFont(f);
        l9.setForeground(Color.YELLOW);
        l9.setBounds(300, 480, 250, 40);
        jj.add(l9);
        tf=new JTextField("ex:dd/mm/yyyy");
        tf.setBounds(600, 480, 250, 40);
        jj.add(tf);
        jb=new JButton("SUBMIT");
        jb.setFont(f);
        jb.setBounds(570,570,150,50);
        jj.add(jb);
        bg = new ButtonGroup();
        bg.add(l4);
        bg.add(l5);
        bg.add(l6);
       jb.addActionListener(this);
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
      String a,a1,a2,a4,a5,a6="Not Selected";
       a=t1.getText();
       a1=t2.getText();
       a2=t3.getText();
     // int x=0,x1,x2;
       a4=t.getText();
       a5=tf.getText();
       
       
       
       if(l4.isSelected())
       {
           a6="$100/Night Mountain View";
           //x=100*(((int)a+(int)a1)/4);
       }
       else if(l5.isSelected())
       {   a6="$120/Night Ocean View";}
       else if(l6.isSelected())
       { a6="$140/Night City View";}
       //System.out.println(s);
       data();
       if(a.isEmpty()||a2.isEmpty()||a4.isEmpty()||a5.isEmpty()||a6.equals("Not Selected")||s.isEmpty()||s1.isEmpty()||s2.isEmpty()||s3.isEmpty()||s4.isEmpty()||s5.isEmpty()||s6.isEmpty()||s7.isEmpty()||s8.isEmpty()||s9.isEmpty()||s10.isEmpty()||gender=='0')
         JOptionPane.showMessageDialog(this, "Error message", "error", JOptionPane.ERROR_MESSAGE);
     /* else if(s.isEmpty()||s1.isEmpty()||s2.isEmpty()||s3.isEmpty()||s4.isEmpty()||s5.isEmpty()||s6.isEmpty())
          JOptionPane.showMessageDialog(this,"Error Message","error",JOptionPane.ERROR_MESSAGE);
      else if(s7.isEmpty()||s8.isEmpty()||s9.isEmpty()||s10.isEmpty()||gender=='0')
        JOptionPane.showMessageDialog(this,"Error Message","error",JOptionPane.ERROR_MESSAGE);
  */

      
    else
      {try{ 
          int z;
          x=Integer.parseInt(a);
       y=Integer.parseInt(a1);
       z=x+y;
       if(z%4!=0)
           z1=(z/4)+1;
       else
           z1=z/4;
       System.out.println("z1 is "+z1);
            Class.forName("com.mysql.jdbc.Driver");
             
            Connection  con = DriverManager.getConnection("jdbc:mysql://localhost:3306/harsh","root","3306");
           // System.out.println(gender);
            //String s = tf.getText();
            String queString = "insert into hotel_registration values(?,?,?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(queString);
            ps.setString(1, s);
            ps.setString(2, s1);
            ps.setString(3, gender+"");
            ps.setString(4, s5+s6);
           ps.setString(5, s7);
           ps.setString(6, s8);ps.setString(7, s2);ps.setString(8, s10);ps.setString(9, s9);ps.setString(10, s3);ps.setString(11, s4);
           ps.setString(12,a4);
           
           
            //ps.setString(2, s);
            int i = ps.executeUpdate();
            if(i>0)
               System.out.println("Success");
           // Connection  conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/harsh","root","3306");
           
            
            String queString1="insert into accomodation values(?,?,?,?,?,?,?,?)";
            PreparedStatement ps1;
            
            ps1 = con.prepareStatement(queString1);
            ps1.setString(1,s4);  
            ps1.setString(2, a);
            ps1.setString(3, a1);
            ps1.setString(4, a2);
            ps1.setString(5, a6);
            ps1.setString(6, a4);
            ps1.setString(7, a5);
            ps1.setString(8, z1+"");
           // ps.setString(7, a3);
           int j=ps1.executeUpdate();
           if(j>0)
              System.out.println("Success");
           //String sss="select * from accomodation";
           
        }
        catch(ClassNotFoundException e1){
            System.out.println("Exception1 :"+e1);
        }
        catch(Exception e1){
            System.out.println("Exception2 :"+e1);
            e1.printStackTrace();
            
        }
      roomalloted();
    
    }
    
    
    
    
    
    
    }
    int zz;
    public void roomalloted(){
        String y;
        if(l4.isSelected())
       {
           y="Night Mountain View";
           zz=z1;
           java.awt.EventQueue.invokeLater(new Runnable() {
          @Override
          public void run() {
              RoomsAlloted rm=new RoomsAlloted(zz,y,100,1);
          }
      });
       }
       else if(l5.isSelected())
       {   y="Night Ocean View";
           zz=z1;
java.awt.EventQueue.invokeLater(new Runnable() {
          @Override
          public void run() {
              RoomsAlloted rm=new RoomsAlloted(zz,y,120,2);
          }
      });
           
       }
       else if(l6.isSelected())
       { y="Night City View";
            zz=z1;
           java.awt.EventQueue.invokeLater(new Runnable() {
          @Override
          public void run() {
              RoomsAlloted rm=new RoomsAlloted(zz,y,140,3);
          }
      });
       }
    }
   
    }
}
