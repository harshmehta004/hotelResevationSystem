
package javaproject;

public class HotelReservationSystem {
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                   Entrypage e=new Entrypage();
            }
            
        });
        
    }
}
