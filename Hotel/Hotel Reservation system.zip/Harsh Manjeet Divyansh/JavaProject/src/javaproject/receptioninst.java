/**
 * MAIN CLASS 
 * HERE THE PROJECT BEGINS...
 */




package javaproject;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
public class receptioninst extends JFrame{
     public receptioninst(){
            setVisible(true);
        setTitle("Welcome");
       // setLocationRelativeTo(null);
        setSize(1366 ,768);
        setLayout(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
         JLabel j=new JLabel();
     j.setBounds(0, 0, 1366, 768);
     ImageIcon i=new ImageIcon("F:\\image.jpeg");
     ImageIcon img=new ImageIcon(i.getImage().getScaledInstance(1366, 768, Image.SCALE_DEFAULT));
     j.setIcon(img);
     getContentPane().add(j);
        
        
        JLabel j1=new JLabel("USERNAME");
        j1.setBounds(400, 200, 200, 50);
        j1.setFont(new Font("Serif",Font.BOLD,25));
        j1.setForeground(Color.YELLOW);
        j.add(j1);
        JTextField t=new JTextField(10);
        t.setBounds(600, 200, 300, 50);
        t.setFont(new Font("Serif",Font.BOLD,25));
        //t.setForeground(Color.YELLOW);
        j.add(t);
        JLabel j2=new JLabel("PASSWORD");
        j2.setBounds(400, 270, 200, 50);
        j2.setFont(new Font("Serif",Font.BOLD,25));
        j2.setForeground(Color.YELLOW);
        j.add(j2);
        
         JPasswordField t1=new JPasswordField(10);
        t1.setBounds(600, 270, 300, 50);
        t1.setFont(new Font("Serif",Font.BOLD,25));
        //t.setForeground(Color.YELLOW);
        j.add(t1);
        JButton b=new JButton("Login");
         b.setBounds(450, 330,120, 50);
        b.setFont(new Font("Serif",Font.BOLD,20));
        //t.setForeground(Color.YELLOW);
        j.add(b);
         JButton b1=new JButton("Reset");
         b1.setBounds(600, 330,120, 50);
        b1.setFont(new Font("Serif",Font.BOLD,20));
        //t.setForeground(Color.YELLOW);
        j.add(b1);
        b.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String s,s1;
                    s=t.getText().toString();s1=t1.getText().toString();
                    
                    if(s.equals("12345")&&s1.equals("3306"))
                        {   
                    java.awt.EventQueue.invokeLater(new Runnable() {
                            @Override
                            public void run() {
                            Status s=new Status();    
                                
                            }
                        });}
                    else
                    {
                        JOptionPane.showMessageDialog(null,"Wrong Username or Password","ERROR",JOptionPane.ERROR_MESSAGE);
                    }
                }
            });
        b1.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                  receptioninst rr=new receptioninst();
                    setVisible(false);
                }
            });
     }
    public static void main(String[] args) {
       java.awt.EventQueue.invokeLater(new Runnable() {
           @Override
           public void run() {
            receptioninst r=new receptioninst();
     }
       });
    
    }
}
