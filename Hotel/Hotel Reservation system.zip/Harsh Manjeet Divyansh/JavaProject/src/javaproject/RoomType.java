
package javaproject;
 
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
 
public class RoomType extends JFrame implements ActionListener{
JLabel l1,l2,l3;
JRadioButton l4,l5,l6;
//JRadioButton rb1,rb2,rb3;
Font f = new Font ("Serif", Font.BOLD, 20);
JTextField t1,t2,t3,t4;
ButtonGroup bg;
    public RoomType(){
       
        setTitle("Accomodation");
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setSize(1366,768);
        setLayout(null);
        l1=new JLabel("Number of Adults");
        l1.setFont(f);
        l1.setBounds(   300, 120, 200, 40);
        add(l1);
        t1=new JTextField("ex: 3");
        t1.setBounds(550,120,240,40);
        add(t1);
        l2=new JLabel("Number of Children\n (if Any)");
        l2.setFont(f);
        l2.setBounds(300, 170, 250, 40);
        add(l2);
        t2=new JTextField("ex: 3");
        t2.setBounds(550, 170, 240, 40);
        add(t2);
        l3=new JLabel("Number of Nights at Hotel");
        l3.setFont(f);
        l3.setBounds(300, 220, 250, 40);
        add(l3);
        t3=new JTextField("ex: 3");
        t3.setBounds(550, 220, 240, 40);
        add(t3);
        JLabel jl=new JLabel("Choose the Type of room You Want");
        jl.setFont(f);
        jl.setBounds(300, 270, 400, 40);
        add(jl);
        l4=new JRadioButton("$100/Night Mountain View");
        l4.setBounds(350, 320, 250, 30);
        add(l4);
        l5=new JRadioButton("$120/Night Ocean View");
        l5.setBounds(350, 370,250,30);
        add(l5);
        l6=new JRadioButton("$140/Night City View");
        l6.setBounds(640, 320, 250, 30);
        add(l6);
        JLabel l7=new JLabel("____________________________________________________________________________________________________________________");
        l7.setBounds(100, 380,1400,30);
        l7.setFont(new Font("Serif",Font.BOLD,20));
        add(l7);
        JLabel l8=new JLabel("Arrival-Date");
        l8.setFont(f);
        l8.setBounds(300, 430, 250, 40);
        add(l8);
        JTextField t=new JTextField("ex:dd/mm/yyyy");
        t.setBounds(550, 430, 250, 30);
        add(t);
         JLabel l9=new JLabel("Departure-Date");
        l9.setFont(f);
        l9.setBounds(300, 480, 250, 40);
        add(l9);
        JTextField tf=new JTextField("ex:dd/mm/yyyy");
        tf.setBounds(550, 480, 250, 40);
        add(tf);
        JButton jb=new JButton("SUBMIT");
        jb.setFont(f);
        jb.setBounds(570,570,150,50);
        add(jb);
        bg = new ButtonGroup();
        bg.add(l4);
        bg.add(l5);
        bg.add(l6);
       jb.addActionListener(this);
        
    }

    public static void main(String[] args) {
        RoomType r=new RoomType();
    }
    @Override
    public void actionPerformed(ActionEvent e) {
       
    }
   
    }

