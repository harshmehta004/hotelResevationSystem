
package javaproject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.swing.*;


public class RoomNO extends JFrame{
 public RoomNO(){
     try{ 
            Class.forName("com.mysql.jdbc.Driver");
             
            Connection  con = DriverManager.getConnection("jdbc:mysql://localhost:3306/harsh","root","3306");
            
            //String s = tf.getText();
            String queString = "insert into roomNo values(?,?)";
            PreparedStatement ps = con.prepareStatement(queString);
            for(int i=1001;i<=1150;i++){
                ps.setString(1, i+"");
                ps.setString(2,"Vacant");
                 ps.executeUpdate();
            }
            String queString1 = "insert into roomNoOV values(?,?)";
            PreparedStatement ps1 = con.prepareStatement(queString1);
           
            for(int i=2001;i<=2150;i++){
                ps1.setString(1, i+"");
                ps1.setString(2,"Vacant");
                 ps1.executeUpdate();
            }
            String queString2 = "insert into roomNoCV values(?,?)";
            PreparedStatement ps2 = con.prepareStatement(queString2);
           
            for(int i=3001;i<=3150;i++){
                ps2.setString(1, i+"");
                ps2.setString(2,"Vacant");
                ps2.executeUpdate();
            }
           
            
         System.out.println("Success");            
//ps.setString(2, s);
            //int i = ps.executeUpdate();
            //if(i>0)
            //  System.out.println("Success");
            
        }
        catch(ClassNotFoundException e){
            System.out.println("Exception1 :"+e);
        }
        catch(Exception e){
            System.out.println("Eception2 :"+e);
        }
}
    public static void main(String[] args) {
        RoomNO rm=new RoomNO();
        
    }
}