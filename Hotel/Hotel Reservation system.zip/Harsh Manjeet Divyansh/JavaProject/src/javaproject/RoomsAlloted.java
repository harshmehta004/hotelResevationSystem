
package javaproject;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.*;
public class RoomsAlloted extends JFrame{
   int xx;String yy;
  int zz;int aa;
    Font f=new Font("Serif",Font.BOLD,25);  
    public RoomsAlloted(int x,String y,int z,int a){
        xx=x;yy=y;zz=z;
        zz=zz*xx;aa=a;
     
            
        setVisible(true);
        setTitle("Type of Room");
        setLocationRelativeTo(null);
        setSize(1366,768);
        setLayout(null);
        setDefaultCloseOperation(HIDE_ON_CLOSE);
        
         JLabel j=new JLabel();
     j.setBounds(0, 0, 1366, 768);
     ImageIcon i=new ImageIcon("F:\\image.jpeg");
     ImageIcon img=new ImageIcon(i.getImage().getScaledInstance(1366, 768, Image.SCALE_DEFAULT));
     j.setIcon(img);
     getContentPane().add(j);
        
        JLabel jj=new JLabel(xx+" "+ yy+" room/s are alloted");
        jj.setBounds(100, 120, 600, 40);
        jj.setFont(f);
        jj.setForeground(Color.YELLOW);
        j.add(jj);
        JLabel j1=new JLabel("Payment to be made is $"+zz);
        j1.setBounds(400, 200,400,40);
        j1.setFont(f);
        j1.setForeground(Color.YELLOW);
        j.add(j1);
        JLabel j2=new JLabel("If amount is paid then click yes else click no");
        j2.setBounds(400, 250,600,40);
        j2.setFont(f);
        j2.setForeground(Color.YELLOW);
        j.add(j2);
        JButton jb=new JButton("YES");
        jb.setBounds(480, 300,70,40);
        //jb.setFont(f);
        jb.setForeground(Color.BLACK);
        j.add(jb);
        JButton jb1=new JButton("NO");
        jb1.setBounds(560, 300,70,40);
        //j1.setFont(f);
        jb1.setForeground(Color.BLACK);
        j.add(jb1);
        jb.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    java.awt.EventQueue.invokeLater(new Runnable() {
                        @Override
                        public void run() {                            
                            Payment p=new Payment(aa,xx);
                            //setVisible(false);
                        }
                    });
                    }
            });
        jb1.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    JOptionPane.showMessageDialog(null, "Room Will be alloted only after complete payment of Rooms", "ERROR in ROOM ALLOTMENT", JOptionPane.PLAIN_MESSAGE);
                }
            });
        
            


       
    }
   /* public void payment(){
        setVisible(true);
        setTitle("Payment");
       setLocationRelativeTo(null);
        setSize(1366,768);
        setLayout(null);
        setDefaultCloseOperation(HIDE_ON_CLOSE);
       JLabel j=new JLabel();
     j.setBounds(0, 0, 1366, 768);
     ImageIcon i=new ImageIcon("F:\\image.jpeg");
     ImageIcon img=new ImageIcon(i.getImage().getScaledInstance(1366, 768, Image.SCALE_DEFAULT));
     j.setIcon(img);
     getContentPane().add(j);
     try{ 
            Class.forName("com.mysql.jdbc.Driver");
             
            Connection  con = DriverManager.getConnection("jdbc:mysql://localhost:3306/harsh","root","3306");
            
            //String s = tf.getText();
            String queString = "Select MVRoom,OVRoom,CVRoom from rooms";
            String queString1="update rooms set MVRoom=?,OVRoom=?,CVRoom=?";
            PreparedStatement ps = con.prepareStatement(queString);
            PreparedStatement ps1=con.prepareStatement(queString1);
            ResultSet rs=ps.executeQuery(queString);
            rs.next();
            int x=0;int y=1000;
            if(aa==1)
            {x=rs.getInt("MVRoom");int a=xx;
            JLabel jjjj=new JLabel("Room number/s Alloted is/are ");
            jjjj.setBounds(400,100,700,40 );
            jjjj.setFont(new Font("Serif",Font.ITALIC,25));
            jjjj.setForeground(Color.YELLOW);
            j.add(jjjj);
            int xx=150;
            for(;a>0;a--)
            {   x=x+1;
                y=y+x;
                JLabel jjj=new JLabel(""+y);
                jjj.setBounds(450, xx, 200, 40);
                jjj.setFont(new Font("Serif",Font.ITALIC,20));
                jjj.setForeground(Color.YELLOW);
                j.add(jjj);
                xx=xx+50;
            }
            }
            else if(aa==2)
            {   x=rs.getInt("OVRoom");
            int a=xx;
              JLabel jjjj=new JLabel("Room number/s Alloted is/are ");
            jjjj.setBounds(400,100,700,40 );
            jjjj.setFont(new Font("Serif",Font.ITALIC,25));
            jjjj.setForeground(Color.YELLOW);
            j.add(jjjj);
            int xx=150;
            for(;a>0;a--)
            {   x=x+1;
                y=y+x;
                JLabel jjj=new JLabel(""+y);
                jjj.setBounds(450, xx, 200, 40);
                jjj.setFont(new Font("Serif",Font.ITALIC,20));
                jjj.setForeground(Color.YELLOW);
                j.add(jjj);
                xx=xx+50;
            }
            
            }
            else if(aa==3)
            {     x=rs.getInt("CVRoom");
            int a=xx;
              JLabel jjjj=new JLabel("Room number/s Alloted is/are ");
            jjjj.setBounds(400,100,700,40 );
            jjjj.setFont(new Font("Serif",Font.ITALIC,25));
            jjjj.setForeground(Color.YELLOW);
            j.add(jjjj);
            int xx=150;
            for(;a>0;a--)
            {   x=x+1;
                y=y+x;
                JLabel jjj=new JLabel(""+y);
                jjj.setBounds(450, xx, 200, 40);
                jjj.setFont(new Font("Serif",Font.ITALIC,20));
                jjj.setForeground(Color.YELLOW);
                j.add(jjj);
                xx=xx+50;
            }
            }
            
            





            //int x=rs.getInt("MVRoom");
            //x=x+1;
            //JLabel jjj=new JLabel("Rooms Alloted is/are "+);
            
            
        }
        catch(ClassNotFoundException e){
            System.out.println("Exception1 :"+e);
        }
        catch(Exception e){
            System.out.println("Eception2 :"+e);
        }
    
    }*/
   /* public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
           RoomsAlloted ra=new RoomsAlloted(1,"hey",2,1);
        
            }
        });
    }*/
}
