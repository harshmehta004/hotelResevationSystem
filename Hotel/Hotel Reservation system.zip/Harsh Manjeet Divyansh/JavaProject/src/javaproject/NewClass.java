
package javaproject;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.*;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.table.DefaultTableModel;

public class NewClass extends JFrame{
  private DefaultTableModel model,model1,model2,model3;
  private JTable table,table1,table2,table3;
    
    public NewClass(){
         setVisible(true);
        setTitle("Welcome");
       // setLocationRelativeTo(null);
        setSize(1366 ,768);
        setLayout(null);
        setDefaultCloseOperation(HIDE_ON_CLOSE);
         JLabel j=new JLabel();
     j.setBounds(0, 0, 1366, 768);
     ImageIcon i=new ImageIcon("F:\\image.jpeg");
     ImageIcon img=new ImageIcon(i.getImage().getScaledInstance(1366, 768, Image.SCALE_DEFAULT));
     j.setIcon(img);
     getContentPane().add(j);
        model = new DefaultTableModel();
        model.addColumn("email");
        model.addColumn("Adults");model.addColumn("Children");
        model.addColumn("Nights");
        model.addColumn("roomType");model.addColumn("Arrival Date");model.addColumn("Departure Date");
        
        
        
        
        try{ 
            Class.forName("com.mysql.jdbc.Driver");
             
            Connection  con = DriverManager.getConnection("jdbc:mysql://localhost:3306/harsh","root","3306");
            
            //String s = tf.getText();
            String queString = "Select * from accomodation";
            PreparedStatement ps = con.prepareStatement(queString);
            ResultSet rs=ps.executeQuery(queString);
             
            while(rs.next()){
                //JTable t1=new Table();
               String[] x1=  {  rs.getString(1),
                    rs.getString(2),
                     rs.getString(3),
                    rs.getString(4),
                    rs.getString(5),
                    rs.getString(6),
                     rs.getString(7),
                    rs.getString(8)};
                      model.addRow(x1);
                      table =new JTable(model);
                      JScrollPane sp=new JScrollPane(table);
                      sp.setBounds(10, 10,700 ,100);
                      j.add(sp);
                      
            }
            
        }
        catch(ClassNotFoundException e){
            System.out.println("Exception1 :"+e);
        }
        catch(Exception e){
            System.out.println("Eception2 :"+e);
        }
    
        model1=new DefaultTableModel();
        model1.addColumn("RoomNo");
        model1.addColumn("Occupancy");
         model2=new DefaultTableModel();
        model2.addColumn("RoomNo");
        model2.addColumn("Occupancy");
         model3=new DefaultTableModel();
        model3.addColumn("RoomNo");
        model3.addColumn("Occupancy");
        
        try{ 
            Class.forName("com.mysql.jdbc.Driver");
          
            Connection  con = DriverManager.getConnection("jdbc:mysql://localhost:3306/harsh","root","3306");
            
            String queString11 = "select * from roomno";
            PreparedStatement pres = con.prepareStatement(queString11);
            ResultSet rs1=pres.executeQuery(queString11);
            String queString12 = "select * from roomnocv";
            PreparedStatement pres1 = con.prepareStatement(queString12);
            ResultSet rs2=pres1.executeQuery(queString12);
            String queString13 = "select * from roomnoov";
            PreparedStatement pres2 = con.prepareStatement(queString13);
            ResultSet rs3=pres2.executeQuery(queString13);
            
            
            
            
            while(rs1.next()){
                rs2.next();
                rs3.next();
                String y1[]={
                rs1.getString(1),rs1.getString(2)
                };model1.addRow(y1);
                table1=new JTable(model1);
                JScrollPane jsp=new JScrollPane(table1);
                jsp.setBounds(30, 190, 200, 200);
                j.add(jsp);
                String y2[]={
                rs2.getString(1),rs2.getString(2)
                };model2.addRow(y2);
                table2=new JTable(model2);
                JScrollPane jsp1=new JScrollPane(table2);
                jsp1.setBounds(470, 190, 200, 200);
                j.add(jsp1);
                String y3[]={
                rs3.getString(1),rs3.getString(2)
                };model3.addRow(y3);
                table3=new JTable(model3);
                JScrollPane jsp2=new JScrollPane(table3);
                jsp2.setBounds(250, 190, 200, 200);
                j.add(jsp2);
            
            
            }
        }
        catch(ClassNotFoundException e){
            System.out.println("Exception1 :"+e);
        }
        catch(Exception e){
            System.out.println("Eception2 :"+e);
        }
    
    
    
    
    }
//    public static void main(String[] args) {
//        NewClass n=new NewClass();
//   }
}
