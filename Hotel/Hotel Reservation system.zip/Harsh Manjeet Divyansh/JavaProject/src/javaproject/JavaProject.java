 
package javaproject;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Statement;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
public class JavaProject extends Entrypage{
   public static void main(String[] args) {
        try{ 
            Class.forName("com.mysql.jdbc.Driver");
             
            Connection  con = DriverManager.getConnection("jdbc:mysql://localhost:3306/harsh","root","3306");
            
            //String s = tf.getText();
            //String queString = "insert into hotel_registration values(?,?,?,?,?,?,?,?,?,?,?)";
            //PreparedStatement ps = con.prepareStatement(queString);
            //ps.setString(1, "fname");
            //ps.setString(2, s);
            //int i = ps.executeUpdate();
            //if(i>0)
            //  System.out.println("Success");
            
        }
        catch(ClassNotFoundException e){
            System.out.println("Exception1 :"+e);
        }
        catch(Exception e){
            System.out.println("Eception2 :"+e);
        }
    }

   
    
}
