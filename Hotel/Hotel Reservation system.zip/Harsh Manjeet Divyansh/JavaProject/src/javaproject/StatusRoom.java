package javaproject;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.*;

public class StatusRoom extends JFrame {

    final int numberOfRoom = 450;
    int roomsBooked, roomsAvailable;
    Font f = new Font("Serif", Font.BOLD, 25);
    JLabel j1, j2;
int ii,iii,iiii;
    public StatusRoom() {
        setVisible(true);
        setTitle("Status Of Rooms");
        setSize(1366, 768);
        setDefaultCloseOperation(HIDE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        JLabel jj = new JLabel();
        jj.setBounds(0, 0, 1366, 768);
        ImageIcon i = new ImageIcon("F:\\image.jpeg");
        ImageIcon img = new ImageIcon(i.getImage().getScaledInstance(1366, 768, Image.SCALE_DEFAULT));
        jj.setIcon(img);
        getContentPane().add(jj);

        try {
            Class.forName("com.mysql.jdbc.Driver");

            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/harsh", "root", "3306");

            //String s = tf.getText();
            String queString = "select * from rooms";
            PreparedStatement ps = con.prepareStatement(queString);
            ResultSet rs = ps.executeQuery(queString);
            rs.next();
            ii = rs.getInt("mountain_view");
            iii = rs.getInt("ocean_view");
            iiii = rs.getInt("city_view");

            //ps.setString(1, "fname");
            //ps.setString(2, s);
            //int i = ps.executeUpdate();
            //if(i>0)
            //  System.out.println("Success");
        } catch (ClassNotFoundException e) {
            System.out.println("Exception1 :" + e);
        } catch (Exception e) {
            System.out.println("Eception2 :" + e);
        }

        JLabel j = new JLabel("Total Number of rooms in Hotel are 450");
        j.setBounds(100, 120, 600, 40);
        j.setFont(f);
        j.setForeground(Color.MAGENTA);
        jj.add(j);
        JLabel j4 = new JLabel("#    150 Night Mountain View Rooms");
        j4.setBounds(250, 170, 600, 30);
        j4.setFont(new Font("Serif", Font.ITALIC, 19));
        j4.setForeground(Color.YELLOW);
        jj.add(j4);
        JLabel j5 = new JLabel("#    150 Night City View Rooms");
        j5.setBounds(250, 210, 600, 30);
        j5.setFont(new Font("Serif", Font.ITALIC, 19));
        j5.setForeground(Color.YELLOW);
        jj.add(j5);
        JLabel j6 = new JLabel("#    150 Night Ocean View Rooms");
        j6.setBounds(250, 250, 600, 30);
        j6.setFont(new Font("Serif", Font.ITALIC, 19));
        j6.setForeground(Color.YELLOW);
        jj.add(j6);

        if (ii > 0 || iii > 0 || iiii > 0) {
            j1 = new JLabel("Yes Rooms Are Available");
            j1.setBounds(490, 300, 600, 40);
            j1.setFont(new Font("Serif", Font.BOLD, 30));
            j1.setForeground(Color.YELLOW);
            jj.add(j1);
        } else {
            j2 = new JLabel("Rooms Not Available");
            j2.setBounds(490, 300, 600, 40);
            j2.setFont(new Font("Serif", Font.BOLD, 30));
            j2.setForeground(Color.YELLOW);
            jj.add(j2);
        }
        JLabel j3 = new JLabel("Number of rooms Available in Night Mountain view are "+ii);
        j3.setBounds(380, 360, 800, 40);
        j3.setFont(f);
        j3.setForeground(Color.ORANGE);
        jj.add(j3);
         JLabel j7 = new JLabel("Number of rooms Available in Night Ocean view are "+iii);
        j7.setBounds(380, 410, 800, 40);
        j7.setFont(f);
        j7.setForeground(Color.ORANGE);
        jj.add(j7);
         JLabel j8 = new JLabel("Number of rooms Available in Night Mountain view are "+ii);
        j8.setBounds(380, 460, 800, 40);
        j8.setFont(f);
        j8.setForeground(Color.ORANGE);
        jj.add(j8);

    }

}
