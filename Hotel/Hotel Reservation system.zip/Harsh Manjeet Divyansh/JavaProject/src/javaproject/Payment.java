
package javaproject;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.*;
import static javax.swing.WindowConstants.HIDE_ON_CLOSE;
public class Payment extends JFrame{
    int aa,xx1;
    public Payment(int b,int x1){
        aa=b;xx1=x1; 
        setVisible(true);
        setTitle("Payment");
       setLocationRelativeTo(null);
        setSize(1366,768);
        setLayout(null);
        setDefaultCloseOperation(HIDE_ON_CLOSE);
       JLabel j=new JLabel();
     j.setBounds(0, 0, 1366, 768);
     ImageIcon i=new ImageIcon("F:\\image.jpeg");
     ImageIcon img=new ImageIcon(i.getImage().getScaledInstance(1366, 768, Image.SCALE_DEFAULT));
     j.setIcon(img);
     getContentPane().add(j);
     try{ 
            Class.forName("com.mysql.jdbc.Driver");
             
            Connection  con = DriverManager.getConnection("jdbc:mysql://localhost:3306/harsh","root","3306");
            
            //String s = tf.getText();
            String queString = "Select * from rooms";
            String queString1="update rooms set MVRoom=?,OVRoom=?,CVRoom=?,mountain_view=?,ocean_view=?,city_view=?";
            PreparedStatement ps = con.prepareStatement(queString);
            PreparedStatement ps1=con.prepareStatement(queString1);
            ResultSet rs=ps.executeQuery(queString);
            rs.next();
           
            
            int x=0,m=0,n=0;int y1=rs.getInt("mountain_view"),y2=rs.getInt("ocean_view"),y3=rs.getInt("city_view");
            if(aa==1)
            { 
            
                x=rs.getInt("MVRoom");m=rs.getInt("OVRoom");n=rs.getInt("CVRoom");
            int a=xx1;int y=1000;
            JLabel jjjj=new JLabel("Room number/s Alloted is/are ");
            jjjj.setBounds(400,100,700,40 );
            jjjj.setFont(new Font("Serif",Font.ITALIC,25));
            jjjj.setForeground(Color.YELLOW);
            j.add(jjjj);
            int xx=150;y=y+x;
            for(;a>0;a--)
            {   x=x+1;
                y=y+1;y1=y1-1;
                String updString="Update roomNo set occupancy=? where RoomNo=?";
                PreparedStatement pres=con.prepareStatement(updString);
                pres.setString(2, y+"");
                JLabel jjj=new JLabel(""+y);
                jjj.setBounds(450, xx, 200, 40);
                jjj.setFont(new Font("Serif",Font.ITALIC,20));
                jjj.setForeground(Color.YELLOW);
                j.add(jjj);
                xx=xx+50;
                pres.setString(1,"Occupied");
                pres.executeUpdate();
            }
            ps1.setString(1, x+"");
            ps1.setString(2,m+"");
            ps1.setString(3, n+"");
            ps1.setString(4,y1+"");
            ps1.setString(5,y2+"");
            ps1.setString(6, y3+"");
            
            }
            else if(aa==2)
            {   x=rs.getInt("OVRoom");m=rs.getInt("MVRoom");n=rs.getInt("CVRoom");
            int a=xx1;int y=2000;
              JLabel jjjj=new JLabel("Room number/s Alloted is/are ");
            jjjj.setBounds(400,100,700,40 );
            jjjj.setFont(new Font("Serif",Font.ITALIC,25));
            jjjj.setForeground(Color.YELLOW);
            j.add(jjjj);
            int xx=150;y=y+x;
            for(;a>0;a--)
            {   x=x+1;
                y=y+1;y2=y2-1;
                String updString1="Update roomNo set occupancy=? where RoomNo=?";
                PreparedStatement pres=con.prepareStatement(updString1);
                pres.setString(2, y+"");
                
                JLabel jjj=new JLabel(""+y);
                jjj.setBounds(450, xx, 200, 40);
                jjj.setFont(new Font("Serif",Font.ITALIC,20));
                jjj.setForeground(Color.YELLOW);
                j.add(jjj);
                xx=xx+50;
                pres.setString(1, "Occupied");
                pres.executeUpdate();
            }
            ps1.setString(1, m+"");
            ps1.setString(2, x+"");
            ps1.setString(3, n+"");
            ps1.setString(4,y1+"");
            ps1.setString(5,y2+"");
            ps1.setString(6, y3+"");
            }
            else if(aa==3)
            {     x=rs.getInt("CVRoom");m=rs.getInt("MVRoom");n=rs.getInt("OVRoom");
            int a=xx1;int y=3000;
              JLabel jjjj=new JLabel("Room number/s Alloted is/are ");
            jjjj.setBounds(400,100,700,40 );
            jjjj.setFont(new Font("Serif",Font.ITALIC,25));
            jjjj.setForeground(Color.YELLOW);
            j.add(jjjj);
            int xx=150;y=y+x;
            for(;a>0;a--)
            {   x=x+1;
                y=y+1;y3=y3-1;
                 String updString2="Update roomNo set occupancy=? where RoomNo=?";
                 PreparedStatement pres =con.prepareStatement(updString2);
                 pres.setString(2, y+"");
                 
                JLabel jjj=new JLabel(""+y);
                jjj.setBounds(450, xx, 200, 40);
                jjj.setFont(new Font("Serif",Font.ITALIC,20));
                jjj.setForeground(Color.YELLOW);
                j.add(jjj);
                xx=xx+50;
                pres.setString(1, "Occupied");
                pres.executeUpdate();
            }
            ps1.setString(1, m+"");
            ps1.setString(2,n+"");
            ps1.setString(3, x+"");
            ps1.setString(4,y1+"");
            ps1.setString(5,y2+"");
            ps1.setString(6, y3+"");
            
            }
            
           

               int iii=ps1.executeUpdate();
               if(iii>0)
                   System.out.println("Room Allotment success");



            //int x=rs.getInt("MVRoom");
            //x=x+1;
            //JLabel jjj=new JLabel("Rooms Alloted is/are "+);
            
            
        }
        catch(ClassNotFoundException e){
            System.out.println("Exception1 :"+e);
        }
        catch(Exception e){
            System.out.println("Eception2 :"+e);
        }
    }
}
