
package javaproject;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.*;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
public class FreeRoom extends JFrame {
    JLabel j1;
    JTextField tf;JButton jb;
    Font f=new Font("Serif",Font.BOLD,25);
    public FreeRoom(){
           setVisible(true);
        setTitle("Welcome");
       // setLocationRelativeTo(null);
        setSize(1366 ,768);
        setLayout(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
         JLabel j=new JLabel();
     j.setBounds(0, 0, 1366, 768);
     ImageIcon i=new ImageIcon("F:\\image.jpeg");
     ImageIcon img=new ImageIcon(i.getImage().getScaledInstance(1366, 768, Image.SCALE_DEFAULT));
     j.setIcon(img);
     getContentPane().add(j);
        
        
        
        j1=new JLabel("Enter the room number ");
        j1.setBounds(300, 120,400,30);
        j1.setFont(f);
        j1.setForeground(Color.YELLOW);
        j.add(j1);
        tf=new JTextField();
        tf.setBounds(600, 120,80, 40);
        j.add(tf);
        
       jb=new JButton("Press");
       jb.setBounds(400, 170, 70, 50);
       j.add(jb);
       jb.addActionListener(new ActionListener() {
               @Override
               public void actionPerformed(ActionEvent e1) {
                     try{ 
            Class.forName("com.mysql.jdbc.Driver");
             
            Connection  con = DriverManager.getConnection("jdbc:mysql://localhost:3306/harsh","root","3306");
            String a=tf.getText();
        int x=Integer.parseInt(a);
            
           if(x>1000&&x<1150){
            String queString = "update roomno set occupancy=? where RoomNo=?";
            PreparedStatement ps = con.prepareStatement(queString);
            ps.setString(2,x+"");
            ps.setString(1, "Vacant");
            ps.executeUpdate();
            
            
            int k=0;
            String str1="Select mountain_view,MVRoom from rooms where mark='"+k+"'";   
            PreparedStatement ps2=con.prepareStatement(str1);
            
            ResultSet rs=ps2.executeQuery(str1);rs.next();
               int x1=rs.getInt("mountain_view"),x2=rs.getInt("MVRoom");x1++;x2--;
            String str="update rooms set mountain_view=?,MVRoom=?";
            PreparedStatement ps1=con.prepareStatement(str);
               
               
               ps1.setString(1,x1+"");
            ps1.setString(2, x2+"");
            int ii=ps1.executeUpdate();
            if(ii>0)
                JOptionPane.showMessageDialog(null, "Successfully Completed Action", "THANKS", JOptionPane.INFORMATION_MESSAGE);
           }
           else if(x>2000&&x<=2150){
           String queString = "update roomnoov set occupancy=? where RoomNo=?";
            PreparedStatement ps = con.prepareStatement(queString);
            ps.setString(2,x+"");
            ps.setString(1, "Vacant");
            ps.executeUpdate();
            
            int k=0;
            String str1="Select ocean_view,OVRoom from rooms where mark='"+k+"'";   
            PreparedStatement ps2=con.prepareStatement(str1);   
            ResultSet rs=ps2.executeQuery(str1);rs.next();
               int x1=rs.getInt("ocean_view"),x2=rs.getInt("OVRoom");x1++;x2--;
            String str="update rooms set ocean_view=?,OVRoom=?";
            PreparedStatement ps1=con.prepareStatement(str);
            
               ps1.setString(1,x1+"");
            ps1.setString(2, x2+"");
           // ps1.executeUpdate();
          int ii=ps1.executeUpdate();
            if(ii>0)
                JOptionPane.showMessageDialog(null, "Successfully Completed Action", "THANKS", JOptionPane.INFORMATION_MESSAGE);
           } 
           else if(x>3000 &&x<=3150){
            String queString = "update roomnocv set occupancy=? where RoomNo=?";
            PreparedStatement ps = con.prepareStatement(queString);
            ps.setString(2,x+"");
            ps.setString(1, "Vacant");
            ps.executeUpdate();
             int k=0;
            //
            String str1="Select city_view,CVRoom from rooms where mark='"+k+"'";   
            PreparedStatement ps2=con.prepareStatement(str1);   
          
            
            ResultSet rs=ps2.executeQuery(str1);rs.next();
               int x1=rs.getInt("city_view"),x2=rs.getInt("CVRoom");x1++;x2--;
           String str="update rooms set city_view=?,CVRoom=?";
            PreparedStatement ps1=con.prepareStatement(str);
           
               ps1.setString(1,x1+"");
            ps1.setString(2, x2+"");
           //ps1.executeUpdate();
          int ii=ps1.executeUpdate();
            if(ii>0)
                JOptionPane.showMessageDialog(null, "Successfully Completed Action", "THANKS", JOptionPane.INFORMATION_MESSAGE);
           }
           else 
               JOptionPane.showMessageDialog(null, "You typed an invalid room number", "ERROR", JOptionPane.ERROR_MESSAGE);
               }
        catch(ClassNotFoundException e){
            System.out.println("Exception1 :"+e);
        }
        catch(Exception e){
            System.out.println("Eception2 :"+e);
        }
               }
           });
       
        
        
      
    }
}
