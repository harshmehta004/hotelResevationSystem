
package javaproject;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
//import JavaProject.*;
public class Status extends JFrame{
Font f=new Font("Serif",Font.ITALIC,40);
Font f1=new Font("Serif",Font.BOLD,25);
    public Status(){
     setTitle("Status");
     setSize(1366,768);
     setLayout(null);
     setLocationRelativeTo(null);
     setDefaultCloseOperation(EXIT_ON_CLOSE);
     setVisible(true);
     
     JLabel j=new JLabel();
     j.setBounds(0, 0, 1366, 768);
     ImageIcon i=new ImageIcon("F:\\image.jpeg");
     ImageIcon img=new ImageIcon(i.getImage().getScaledInstance(1366, 768, Image.SCALE_DEFAULT));
     j.setIcon(img);
     getContentPane().add(j);
     
     JLabel j1=new JLabel("Lalit Hotel");
     j1.setBounds(410, 10, 400, 50);
     j1.setFont(f);
     j1.setForeground(Color.MAGENTA);
     j.add(j1);
     //JLabel j2=new JLabel("Choose any one of the below options ");
     //j2.setBounds(410, 120  ,400, 40);
     //j2.setFont(f1);
     //j2.setForeground(Color.YELLOW);
     //j.add(j2);
     JRadioButton r=new JRadioButton("Check if the Rooms Are available");
     JRadioButton r1=new JRadioButton("Check");
     JLabel j2=new JLabel("To check Availability of rooms >>");
     j2.setBounds(450, 120, 650, 50);
     j2.setFont(f1);
     j2.setForeground(Color.YELLOW);
     j.add(j2);
     JButton b=new JButton("Click Here");
     b.setBounds(850, 120, 140, 50);
     b.setBackground(Color.CYAN);b.setFont(new Font("Serif",Font.BOLD,20));
     j.add(b);
     JLabel j3=new JLabel("To book room >>");
     j3.setBounds(450, 190, 600, 50);
     j3.setFont(f1);
     j3.setForeground(Color.YELLOW);
     j.add(j3);
     JButton b1=new JButton("Click Here");
     b1.setBounds(850, 190, 140, 50);
     b1.setFont(new Font("Serif",Font.BOLD,20));
     //b1.setFont(f1);
     b1.setBackground(Color.CYAN);
     j.add(b1);
     JLabel jl=new JLabel("To check List of Guests >>");
     jl.setBounds(450,260,600,50);
     jl.setFont(f1);
     jl.setForeground(Color.YELLOW);
     j.add(jl);
     JButton jb=new JButton("Click Here");
    // jb.setForeground(Color.red);
    jb.setBounds(850, 260, 140, 50);
    jb.setFont(new Font("Serif",Font.BOLD,20));
    jb.setBackground(Color.CYAN);
    j.add(jb);
    JLabel jla=new JLabel("To check on Customer leaving >>");
    jla.setBounds(450, 330, 600, 50);
    jla.setFont(f1);
    jla.setForeground(Color.YELLOW);
    j.add(jla);
    JButton jbu=new JButton("Click Here");
     jbu.setBounds(850, 330, 140, 50);
    jbu.setFont(new Font("Serif",Font.BOLD,20));
    jbu.setBackground(Color.CYAN);
    j.add(jbu);
    jbu.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
                     java.awt.EventQueue.invokeLater(new Runnable() {
                 @Override
                 public void run() {
                        FreeRoom f=new FreeRoom();
                 }
             });
         
         }
     });
    jb.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
             java.awt.EventQueue.invokeLater(new Runnable() {
                 @Override
                 public void run() {
                        NewClass n=new NewClass();
                 }
             });
         }
     });
    b.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
             //ByProduct v=new ByProduct();
             StatusRoom sr=new StatusRoom();
         }
     });
     b1.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
           //HotelReservationSystem h=new HotelReservationSystem();
               java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                   Entrypage e=new Entrypage();
            }
            
        });
           
           
         }
     });
     
     
 }   
//    public static void main(String[] args) {
//       java.awt.EventQueue.invokeLater(new Runnable() {
//           @Override
//           public void run() {
//               Status s=new Status(); }
//       }); 
//    }
}
